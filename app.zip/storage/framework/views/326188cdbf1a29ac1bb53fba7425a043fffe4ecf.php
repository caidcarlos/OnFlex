<?php $__env->startSection('content'); ?>

    <h1>You are currently not connected to any networks.</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ihyk746s188l/public_html/onflexbeta/resources/views/vendor/laravelpwa/offline.blade.php ENDPATH**/ ?>